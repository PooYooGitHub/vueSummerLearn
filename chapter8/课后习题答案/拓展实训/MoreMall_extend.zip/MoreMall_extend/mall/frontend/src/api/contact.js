import axios from "./axios"

const list = () => {
    return axios.request({
        url: "/contact/list"
    })
}

const add = contact =>
{
    return axios.request({
        url: "/contact/add",
        data: contact,
        method: "post",
    });
}

const deleteById = id => {
    return axios.request({
        url: "/contact/delete",
        method: "post",
        data: { id }
    });
}

const updateById = contact => 
{
    return axios.request({
        url: "/contact/update",
        method: "post",
        data: contact,
    });
}

export default {
    list,
    add,
    deleteById,
    updateById,
}
