<template>
    <div>
        <ul class="tan-contact-list">
            <li v-for="contact in contacts" :key="contact.id" class="tan-contact-list-item" 
                :class="{active: contact.id == currentId}" 
                @click="$emit('click', contact.id)"
            >
                <div class="tan-contact-info">
                    <div class="tan-contact-info-name">
                        {{ contact.name }}
                        <span>{{ contact.tag }}</span>
                    </div>
                    <span class="tan-contact-info-tel">{{ contact.telephone }}</span>
                    <span class="tan-contact-info-address">{{ contact.address }}</span>
                </div>
                <div class="tan-contact-action">
                    <span @click.stop="tmpDeleteId = contact.id, deleteVisible = true">删除</span>
                    <span @click.stop="updateById(contact)">修改</span>
                </div>
            </li>
            <li class="tan-contact-list-item tan-contact-add" @click="visible=true, type = 'add'">
                <div class="tan-contact-add-desc">
                    <div class="tan-contact-add-icon">
                        <div class="tan-contact-add-icon-warp">
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                    添加新地址
                </div>
            </li>
        </ul>
        <tan-modal 
            footer
            :title="type == 'add' ? '添加收货地址' : '修改收货地址'"
            :width="660"
            :visible=visible
            @close="closeAddContact"
        >
            <div class="tan-contact-add-modal">
                <div class="tan-contact-add-modal-meta">
                    <tan-input label="姓名" v-model="contact.name"></tan-input>
                    <tan-input label="手机号" v-model="contact.telephone"></tan-input>
                </div>
                <tan-input label="详细地址" placeholder="详细地址" v-model="contact.address"></tan-input>
                <tan-input label="地址标签" placeholder="如“家”，限制5个字内" v-model="contact.tag"></tan-input>
            </div>
            <template v-slot:footer>
                <tan-button primary width="160px" height="40px" @click="type == 'add' ? addContact() : updateContact()">确定</tan-button>
                <tan-button gray width="160px" height="40px" @click="closeAddContact">取消</tan-button>
            </template>
        </tan-modal>
        <tan-modal
            footer
            title="确认删除"
            :visible="deleteVisible"
            @close="cancalDelete"
        >
            <h2>确认删除？</h2>
            <template v-slot:footer>
                <tan-button primary width="160px" height="40px" @click="confirmDelete">确定</tan-button>
                <tan-button gray width="160px" height="40px" @click="cancalDelete">取消</tan-button>
            </template>
        </tan-modal>
    </div>
</template>

<script>
import modal from "@/components/modal"
import input from "@/components/input"
import contactHttp from "@/api/contact"

export default {
    name: "TanAddressList",
    components: { "tan-modal": modal, "tan-input": input },
    model: {
        prop: "contacts",
        event: "change",
    },
    props: {
        contacts: {
            type: Array,
            default: [],
        },
        currentId: Number,
    },
    data()
    {
        return {
            type: "add",
            visible: false,
            deleteVisible: false,
            tmpDeleteId: null,
            contact: {
                name: null,
                telephone: null,
                address: null,
                tag: null,
            }
        }
    },
    methods: {
        closeAddContact()
        {
            this.visible = false;
            this.contact = {
                name: null,
                telephone: null,
                address: null,
                tag: null,
            };
        },
        check()
        {
            // check
            if ( !this.contact.name ) 
            {
                this.$error("请输入收货人姓名");
                return false;
            }
            if ( !this.contact.telephone )
            {
                this.$error("请输入收货人电话");
                return false;
            }
            if ( !/0?(13|14|15|18|17)[0-9]{9}/.test(this.contact.telephone) ) 
            {
                this.$error("请输入正确的电话");
                return false;
            }
            if ( !this.contact.address ) 
            {
                this.$error("请输入收货地址");
                return false;
            }
            if ( !this.contact.tag )
            {
                this.$error("请输入标签");
                return false;
            }
            if ( this.contact.tag.length > 5 )
            {
                this.$error("标签长度在5个字内");
                return false;
            }
            return true;
        },
        addContact()
        {
            if ( !this.check() ) true;
            contactHttp.add(this.contact)
                .then(resp => {
                    if ( resp.code != 200 )
                    {
                        this.$error(resp.message);
                        return;
                    }
                    this.contact.id = resp.data;
                    this.contacts.push(this.contact);
                    this.closeAddContact();
                });
        },
        cancalDelete()
        {
            this.deleteVisible = false;
        },
        confirmDelete() 
        {
            this.deleteById(this.tmpDeleteId);
        },
        deleteById(id)
        {
            contactHttp.deleteById(id)
                .then(resp => {
                    if ( resp.code != 200 )
                    {
                        this.$error(resp.message);
                        return;
                    }
                    this.$success(resp.message);
                    for ( let i = 0; i < this.contacts.length; i ++ )
                        if ( this.contacts[i].id == id ) 
                            this.contacts.splice(i, 1)
                    this.deleteVisible = false;
                });
        },
        updateById(contact)
        {
            this.type = "update";
            this.contact = Object.assign({}, contact);
            this.visible = true;
        },
        updateContact()
        {
            if ( !this.check() ) true;
            contactHttp.updateById(this.contact)
                .then(resp => {
                    if ( resp.code != 200 )
                    {
                        this.$error(res.message);
                        return;
                    }
                    this.$success(resp.message);
                    if ( resp.data )
                        for ( let i = 0; i < this.contacts.length; i ++ )
                            if ( this.contacts[i].id == this.contact.id )
                            {
                                Object.assign(this.contacts[i], resp.data);
                                break;
                            }
                    this.closeAddContact();
                });
        }
    }
}
</script>

<style>
.tan-contact-list {
    display: flex;
    flex-wrap: wrap;
}

.tan-contact-list-item {
    width: 268px;
    height: 178px;
    border: 1px solid #e0e0e0;
    cursor: pointer;
    line-height: 22px;
    color: #757575;
    position: relative;
    transition: all .3s;
}

.tan-contact-list-item:not(:nth-child(4n + 4)) {
    margin: 0 17px 20px 0;
}

.tan-contact-list > .tan-contact-list-item.active {
    border-color: #ff6700;
}

.tan-contact-info {
    padding: 15px 24px 0;
}

.tan-contact-info-name {
    font-size: 18px;
    color: #333;
    line-height: 30px;
    margin-bottom: 10px;
    position: relative;
}

.tan-contact-info-name > span {
    position: absolute;
    right: 0;
    color: #b0b0b0;
}

.tan-contact-info-tel,
.tan-contact-info-address {
    display: block;
}

.tan-contact-action {
    position: absolute;
    right: 24px;
    bottom: 10px;
    color: #ff6700;
    opacity: 0;
    transition: all .3s;
}

.tan-contact-action > span {
    margin-left: 10px;
}

.tan-contact-list-item:hover {
    border-color: #b0b0b0;
}

.tan-contact-list-item:hover > .tan-contact-action {
    opacity: 1;
}

.tan-contact-list-item:hover .tan-contact-add-icon
{
    background-color: #b0b0b0;
}


.tan-contact-add
{
    display: flex;
    align-items: center;
}

.tan-contact-add-desc
{
    width: 100%;
    text-align: center;
    color: #b0b0b0;
}

.tan-contact-add-icon
{
    display: flex;
    width: 30px;
    height: 30px;
    margin: 0 auto 8px;
    background-color: #e0e0e0;
    border-radius: 17px;
    transition: all .4s ease;
    align-items: center;
    justify-items: center;
}

.tan-contact-add-icon-warp
{
    width: 100%;
    transform: translateX(-0.5px) translateY(-1px);
}

.tan-contact-add-icon-warp > span
{
    display: block;
    width: 17px;
    border-bottom: 3px solid #fff;
    margin: 0 auto;
}

.tan-contact-add-icon-warp > span:first-child
{
    transform: rotate(90deg) translateX(3px);
}

.tan-contact-add-modal-meta
{
    display: flex;
    flex-wrap: wrap;
}

.tan-contact-add-modal-meta > .tan-input
{
    width: 303px;
}

.tan-contact-add-modal-meta > .tan-input:first-child
{
    margin-right: 14px;
}

</style>