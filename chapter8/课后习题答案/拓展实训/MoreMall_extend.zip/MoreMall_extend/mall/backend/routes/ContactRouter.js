let express = require('express')
let router = express.Router()
let contaceController = require("../controllers/ContactController")

router.get("/list", contaceController.listByUserId)
router.post("/add", contaceController.add);
router.post("/delete", contaceController.deleteById);
router.post("/update", contaceController.updateById);

module.exports = router
