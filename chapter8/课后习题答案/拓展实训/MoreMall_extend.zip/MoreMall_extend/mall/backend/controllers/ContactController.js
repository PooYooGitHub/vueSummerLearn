let db = require("../commons/db")
let JSONResponse = require("../commons/JSONResponse")

exports.listByUserId = (req, reps) => {
    let userId = req.session.user.id
    if ( !userId ) {
        reps.json(JSONResponse.fail("必须要有用户id"))
        return
    }
    db.query("select * from contact where user_id = ?", userId)
        .then(contants => {
            reps.json(JSONResponse.success(contants))
        })
}

exports.add = (req, resp) =>
{
    let data = req.body;
    data.userId = req.session.user.id;
    // check
    if ( !data.name ) 
    {
        resp.json(JSONResponse.fail("请输入收货人姓名"));
        return;
    }
    if ( !data.telephone )
    {
        resp.json(JSONResponse.fail("请输入收货人电话"));
        return;
    }
    if ( !/0?(13|14|15|18|17)[0-9]{9}/.test(data.telephone) ) 
    {
        resp.json(JSONResponse.fail("请输入正确的电话"));
        return;
    }
    if ( !data.address ) 
    {
        resp.json(JSONResponse.fail("请输入收货地址"));
        return;
    }
    if ( !data.tag )
    {
        resp.json(JSONResponse.fail("请输入标签"));
        return;
    }
    if ( data.tag.length > 5 )
    {
        resp.json(JSONResponse.fail("标签长度在5个字内"));
        return;
    }
    let now = new Date();
    db.update("insert into contact(name, telephone, address, tag, create_time, update_time, user_id) values(?, ?, ?, ?, ?, ?, ?)", 
                data.name, data.telephone, data.address, data.tag, now, now, data.userId)
        .then(insertRes => {
            // 非0为真，则插入成功
            if ( !insertRes.affectedRows ) {
                resp.json(JSONResponse.fail("添加联系人失败", 500));
                return;
            }
            resp.json(JSONResponse.success(insertRes.insertId, 200, "添加联系人成功"));
        })
        .catch(error => {
            console.log(error)
            resp.json(JSONResponse.fail("添加联系人失败", 500))
        });
}


exports.deleteById = (req, resp) =>
{
    let id = req.body.id;
    if ( !id )
    {
        reps.json(JSONResponse.fail("id 不能为空", 400));
        return;
    }
    db.update("delete from contact where id = ? and user_id = ?", id, req.session.user.id)
        .then(deletRes => {
            if ( !deletRes.affectedRows )
            {
                resp.json(JSONResponse.fail("没有该联系人", 400));
                return;
            }
            resp.json(JSONResponse.success(null, 200, "删除联系人成功"));
        })
        .catch(errors => {
            console.log(errors)
            resp.json(JSONResponse.fail("删除联系人失败", 500))
        });
}

exports.updateById = (req, resp) => 
{
    let data = req.body;
    let now = new Date();
    db.update("update contact set name=?, telephone=?, address = ?, tag = ?, update_time = ? where id = ? and user_id = ?", 
                data.name, data.telephone, data.address, data.tag, now, data.id, data.userId)
        .then(updateRes => {
            if ( !updateRes.affectedRows )
            {
                resp.json(JSONResponse.fail("没有该联系人", 400))
                return;
            }
            data.updateTime = now;
            resp.json(JSONResponse.success(data, 200, "修改成功"));
        })
        .catch(errors => {
            console.log(errors)
            resp.json(JSONResponse.fail("修改联系人失败", 500))
        });
}
